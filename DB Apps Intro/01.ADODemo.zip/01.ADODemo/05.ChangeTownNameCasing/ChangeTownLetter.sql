﻿USE MinionsDB

Select TownName from Towns
Where CountryName=@countryName