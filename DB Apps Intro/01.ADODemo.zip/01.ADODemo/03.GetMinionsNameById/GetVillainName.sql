﻿Use MinionsDB

Select Name from Villains
Where Id=@villainId